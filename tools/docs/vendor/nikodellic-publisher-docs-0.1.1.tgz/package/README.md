# Publisher docs

A CSS-only layer over VitePress 1.6.4. No runtime, appearance controller, or custom layout.

Pack with `npm pack`. Commit the archive under each consumer's `tools/docs/vendor/`, install it in the docs workspace, and import `@nikodellic/publisher-docs/style.css` after `vitepress/theme`. Keep the same exact VitePress version in every site.

Use the native appearance toggle and local search. Content, navigation, logos, API generation, and embedded applications belong to the consumer. The only layout overrides keep the header stationary and prevent the sidebar background extending behind the title.

To update: increment the package version, pack, replace each consumer's archive and lockfile, then build and check each site in light/dark mode and on mobile. Do not publish this private package to npm.
