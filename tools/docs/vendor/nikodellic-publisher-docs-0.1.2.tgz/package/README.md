# Publisher docs

A CSS-only layer over VitePress 1.6.4. No runtime, appearance controller, or custom layout.

Pack with `npm pack`. Commit the archive under each consumer's `tools/docs/vendor/`, install it in the docs workspace, and import `@nikodellic/publisher-docs/style.css` after `vitepress/theme`. Keep the same exact VitePress version in every site.

Use the native appearance toggle and local search. Content, navigation, logos, API generation, and embedded applications belong to the consumer. The shared neutral palette uses the same background for the page, sidebar, and navigation in both light and dark modes. The navbar keeps the same height and alignment across home, guide, and API pages, without a bottom divider. Search, controls, and code blocks use the shared semantic VitePress tokens.

To update: increment the package version, pack, replace each consumer's archive and lockfile, then build and check each site in light/dark mode and on mobile. Do not publish this private package to npm.

Copy `starter/` into a new repository, run `npm ci`, then `npm run docs:dev`.
The starter includes its local CSS archive and lockfile. Configure branding,
navigation, and content with ordinary VitePress configuration. Use the built-in
GitHub high-contrast syntax themes demonstrated in the starter.

Run cross-site browser checks with:

```sh
node scripts/check-site.mjs /absolute/consumer/repo docs/dist SearchTerm
```

Use `dist` for Quilt. The consumer supplies Playwright. Set `SITE_URL` to test a
live deployment. These checks cover the home/docs/API routes, search, mobile
navigation, sidebar placement, and native light/dark persistence of the full sites.
